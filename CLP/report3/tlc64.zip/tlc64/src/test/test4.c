main()
{
    int a, b;
    a = 2;
    b = 1;
    if (a > b) {
        b = a;
        b = b +1;
    }
    put_int(b);
}
