func(int a1, int a2, int a3, int a4, int a5, int a6, int a7, int a8)
{
    int v1, v2, v3;

    v1 = a1+a2+a3+a4+a5+a6+a7+a8;
    v2 = 9;
    v3 = 10;
    v1 = v1+v2+v3;
    put_int(v1);
    return v1;
}

main()
{
    int a;
    a = func(1, 2, 3, 4, 5, 6, 7, 8);
    put_int(a);
}
