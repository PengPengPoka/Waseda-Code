sum(int a, int b)
{
    return a-b;
}

main()
{
    int a;
    a = sum(1, 2);
    put_int(a);
}
