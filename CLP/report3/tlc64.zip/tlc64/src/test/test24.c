sum(int a, int b)
{
    int c;
    c = a-b;
    put_int(c);
    return c;
}

main()
{
    int a;
    a = sum(1, 2);
    put_int(a);
}
