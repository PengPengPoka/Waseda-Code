main()
{
    put_int(1);
}
