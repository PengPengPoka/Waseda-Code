main()
{
    int a;
    a = 5;
    a = -a;
    put_int(a);
}
