main()
{
    int a, b, c, d;
    a = 2; b = 3; c = 4; d = 5;
    a = a * b + c * d;
    put_int(a);
}
