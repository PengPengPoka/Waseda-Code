main()
{
    int a, b, c, d;
    a = a+(b+(c+d));
}
