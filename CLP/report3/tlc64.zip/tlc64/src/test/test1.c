main()
{
    int a;
    int b;
    b = 5;
    a = b+1;
    put_int(a);
}
