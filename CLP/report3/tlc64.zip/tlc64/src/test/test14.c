main()
{
    int a, b, c;
    a = 1;
    b = 2;
    c = a < b;
    put_int(c);
}
