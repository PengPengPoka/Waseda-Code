main()
{
    int a, b, c, d;
    a = 1; b = 2; c = 3; d = 4;
    a = a+b+c+d;
    put_int(a);
}
