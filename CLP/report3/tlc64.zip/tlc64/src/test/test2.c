main()
{
    int a, b;
    b = 3;
    a = b+1;
    put_int(a);
    a = b+2;
    put_int(a);
}
