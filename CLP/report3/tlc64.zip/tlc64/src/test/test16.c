main()
{
    int a, b;
    a = 2; b = 3;
    a = a*b;
    put_int(a);
}
