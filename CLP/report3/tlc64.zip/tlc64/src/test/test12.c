main()
{
    int i;
    i = 10;
    while (i) {
        put_int(i);
        i = i - 1;
    }
}
