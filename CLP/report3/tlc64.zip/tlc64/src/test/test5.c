main()
{
    int a;
    int b;
    a = 2;
    b = 2;

    if ( a == b ) a = 10;
    put_int(a);
}
